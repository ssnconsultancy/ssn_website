import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import { insertContactMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for contact form submissions
  app.post("/api/contact", async (req, res) => {
    try {
      // Validate the request body against our schema
      const validatedData = insertContactMessageSchema.parse(req.body);
      
      // Store the contact message
      const message = await storage.createContactMessage(validatedData);
      
      // Return success response
      res.status(200).json({ 
        success: true, 
        message: "Thank you for your message! We will get back to you soon.",
        data: message 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        // Validation error
        res.status(400).json({ 
          success: false, 
          message: "Invalid form data", 
          errors: error.errors 
        });
      } else {
        // Other error
        console.error("Error saving contact message:", error);
        res.status(500).json({ 
          success: false, 
          message: "An error occurred while saving your message. Please try again later." 
        });
      }
    }
  });

  // API route to get all contact messages (for admin purposes)
  app.get("/api/contact", async (req, res) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.status(200).json({ success: true, data: messages });
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ 
        success: false, 
        message: "An error occurred while fetching messages." 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
