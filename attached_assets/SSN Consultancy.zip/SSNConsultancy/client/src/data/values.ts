export interface Value {
  title: string;
  description: string;
}

export const companyValues: Value[] = [
  {
    title: "Integrity",
    description: "We maintain the highest ethical standards in all our operations and relationships."
  },
  {
    title: "Innovation",
    description: "We constantly seek creative solutions to complex public sector challenges."
  },
  {
    title: "Collaboration",
    description: "We work alongside our clients as true partners in their success journey."
  },
  {
    title: "Excellence",
    description: "We strive for the highest quality in every deliverable and interaction."
  },
  {
    title: "Social Impact",
    description: "We measure our success by the positive change we create in communities."
  },
  {
    title: "Sustainability",
    description: "We design solutions with long-term environmental and financial viability."
  },
  {
    title: "Trust",
    description: "We build lasting relationships founded on reliability and transparency."
  }
];
