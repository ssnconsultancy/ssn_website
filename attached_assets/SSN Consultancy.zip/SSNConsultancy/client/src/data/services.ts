export interface Service {
  title: string;
  description: string;
  features: string[];
}

// Core services shown on homepage
export const coreServices = [
  {
    title: "IT Architecture & Infrastructure",
    description: "Building robust technological foundations for government organizations."
  },
  {
    title: "PMO Implementation",
    description: "Strategic project management for efficient delivery of public sector initiatives."
  },
  {
    title: "Training & Capacity Building",
    description: "Empowering public servants with essential digital skills and knowledge."
  }
];

// All services for the services page
export const allServices: Service[] = [
  {
    title: "IT Architecture & Infrastructure",
    description: "Strategic design and implementation of technology frameworks that support long-term organizational goals.",
    features: [
      "Network design & optimization",
      "Hardware procurement & configuration",
      "System integration services"
    ]
  },
  {
    title: "PMO Implementation",
    description: "Establishing effective Project Management Offices to oversee complex government initiatives.",
    features: [
      "Project governance frameworks",
      "Resource allocation optimization",
      "Progress tracking & reporting"
    ]
  },
  {
    title: "Training & Capacity Building",
    description: "Empowering public servants with essential digital skills and knowledge.",
    features: [
      "Custom training programs",
      "Knowledge transfer workshops",
      "Digital literacy assessment"
    ]
  },
  {
    title: "AWS Cloud Services",
    description: "Leveraging the power of Amazon Web Services to create scalable, secure government solutions.",
    features: [
      "Cloud migration strategies",
      "AWS architecture design",
      "Managed cloud services"
    ]
  },
  {
    title: "Database Management",
    description: "Comprehensive database solutions for secure, efficient public sector data handling.",
    features: [
      "Database design & optimization",
      "Data migration & integration",
      "Performance monitoring"
    ]
  },
  {
    title: "Cybersecurity & Compliance",
    description: "Protecting critical government systems and ensuring regulatory compliance.",
    features: [
      "Security audit & assessment",
      "Compliance documentation",
      "Threat monitoring & response"
    ]
  },
  {
    title: "Banking Consultancy",
    description: "Specialized IT solutions for public sector financial institutions.",
    features: [
      "Financial system integration",
      "Payment processing solutions",
      "Banking security compliance"
    ]
  }
];
