interface SectionHeadingProps {
  tagline: string;
  title: string;
  description?: string;
  centered?: boolean;
  taglineColor?: 'highlight' | 'default';
}

const SectionHeading = ({ 
  tagline, 
  title, 
  description, 
  centered = false, 
  taglineColor = 'highlight' 
}: SectionHeadingProps) => {
  return (
    <div className={`${centered ? 'text-center' : ''} mb-16`}>
      <div className={`inline-block px-4 py-1 ${taglineColor === 'highlight' ? 'bg-[#ff3c1f] bg-opacity-10' : 'bg-[#26313b] bg-opacity-10'} rounded-full mb-4`}>
        <span className={`${taglineColor === 'highlight' ? 'text-[#ff3c1f]' : 'text-[#26313b]'} font-medium`}>
          {tagline}
        </span>
      </div>
      <h2 className="text-3xl md:text-4xl font-bold font-inter mb-4">{title}</h2>
      {description && (
        <p className={`text-[#4e5860] ${centered ? 'max-w-3xl mx-auto' : ''}`}>
          {description}
        </p>
      )}
    </div>
  );
};

export default SectionHeading;
