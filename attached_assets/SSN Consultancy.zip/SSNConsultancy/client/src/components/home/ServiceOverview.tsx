import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { coreServices } from "@/data/services";
import { 
  ServerIcon, 
  ClipboardListIcon, 
  UsersIcon 
} from "lucide-react";

const ServiceOverview = () => {
  // Map of service icons
  const serviceIcons: Record<string, React.ReactNode> = {
    "IT Architecture & Infrastructure": <ServerIcon className="text-[#ff3c1f] text-2xl" />,
    "PMO Implementation": <ClipboardListIcon className="text-[#ff3c1f] text-2xl" />,
    "Training & Capacity Building": <UsersIcon className="text-[#ff3c1f] text-2xl" />
  };
  
  return (
    <section className="py-16 bg-[#fafbfc]">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-4">Our Core Services</h2>
          <p className="text-[#4e5860] max-w-3xl mx-auto">Comprehensive IT solutions tailored for public sector transformation</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {coreServices.map((service) => (
            <div key={service.title} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
              <div className="bg-[#26313b] bg-opacity-10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                {serviceIcons[service.title] || <ServerIcon className="text-[#ff3c1f] text-2xl" />}
              </div>
              <h3 className="text-xl font-bold font-inter mb-3">{service.title}</h3>
              <p className="text-[#4e5860]">{service.description}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Link href="/services">
            <Button className="bg-[#26313b] text-white py-3 px-6 rounded font-medium hover:bg-opacity-90 transition-all duration-200">
              View All Services
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServiceOverview;
