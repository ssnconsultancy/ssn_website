import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="bg-[#26313b] text-white py-20 lg:py-32 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0">
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#ff3c1f] rounded-full opacity-10 blur-3xl"></div>
      </div>
      <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 max-w-2xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter leading-tight">
              Driving Innovation for Public Good
            </h1>
            <p className="text-lg md:text-xl text-[#d9e0e2]">
              SSN Consultancy specializes in transforming public sector technology across Uttarakhand, delivering cutting-edge IT solutions that empower communities and government services.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link href="/services">
                <Button className="bg-[#ff3c1f] text-white py-3 px-6 rounded font-medium hover:bg-opacity-90 transition-all duration-200 w-full sm:w-auto">
                  Explore Our Services
                </Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" className="bg-transparent border border-white text-white py-3 px-6 rounded font-medium hover:bg-white hover:bg-opacity-10 transition-all duration-200 w-full sm:w-auto">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
          <div className="hidden lg:flex justify-center items-center">
            <div className="relative w-full max-w-md aspect-square">
              <div className="absolute top-0 left-0 w-full h-full bg-[#ff3c1f] opacity-10 rounded-full"></div>
              <svg className="w-full h-full text-white opacity-20" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                <path fill="currentColor" d="M45.1,-52.4C59.3,-41.5,72.2,-27.7,76.8,-11.2C81.3,5.4,77.5,24.8,67.1,39.2C56.8,53.6,39.9,63,21.9,69.1C3.9,75.3,-15.1,78.1,-30.9,71.5C-46.7,64.9,-59.4,48.8,-68.9,30.6C-78.4,12.3,-84.7,-8.1,-79,-25.2C-73.3,-42.2,-55.5,-55.9,-38.2,-65.6C-20.9,-75.3,-4.1,-81.1,10.3,-75.9C24.7,-70.7,30.9,-63.2,45.1,-52.4Z" transform="translate(100 100)" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
