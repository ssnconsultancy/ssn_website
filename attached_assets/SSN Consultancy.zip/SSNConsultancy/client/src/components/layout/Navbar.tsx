import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { text: "Home", href: "/" },
    { text: "About", href: "/about" },
    { text: "Services", href: "/services" },
    { text: "Success Story", href: "/success-story" },
    { text: "Values", href: "/values" },
    { text: "Contact", href: "/contact" },
  ];

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <nav className="bg-[#26313b] text-white py-4 sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold font-inter">
              SSN<span className="text-[#ff3c1f]">.</span>
            </Link>
          </div>
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-white" 
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
          
          {/* Desktop navigation */}
          <div className="hidden md:flex space-x-8">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href} 
                className={`text-white hover:text-[#ff3c1f] transition-colors duration-200 ${
                  location === link.href ? "text-[#ff3c1f]" : ""
                }`}
              >
                {link.text}
              </Link>
            ))}
          </div>
          
          {/* Contact button */}
          <div className="hidden md:block">
            <Link href="/contact">
              <Button className="bg-[#ff3c1f] text-white hover:bg-opacity-90 transition-all duration-200">
                Get in Touch
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-2">
            <div className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <Link 
                  key={link.href} 
                  href={link.href} 
                  className={`text-white hover:text-[#ff3c1f] transition-colors duration-200 ${
                    location === link.href ? "text-[#ff3c1f]" : ""
                  }`}
                  onClick={closeMobileMenu}
                >
                  {link.text}
                </Link>
              ))}
              <Link href="/contact" onClick={closeMobileMenu}>
                <Button className="bg-[#ff3c1f] text-white w-full hover:bg-opacity-90 transition-all duration-200 mt-2">
                  Get in Touch
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
