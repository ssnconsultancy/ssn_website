import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Additional styles for Inter and Source Sans Pro fonts
document.documentElement.classList.add('font-source');

createRoot(document.getElementById("root")!).render(<App />);
