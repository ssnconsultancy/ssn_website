import SectionHeading from "@/components/common/SectionHeading";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckIcon } from "lucide-react";

const About = () => {
  return (
    <div className="bg-[#fafbfc]">
      {/* About Hero */}
      <section className="bg-[#26313b] text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0"></div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter mb-6">About SSN Consultancy</h1>
            <p className="text-lg text-[#d9e0e2]">
              Leading the charge in transforming public sector technology across Uttarakhand
            </p>
          </div>
        </div>
      </section>
      
      {/* Vision and Mission */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading 
                tagline="Our Story" 
                title="Building Better Public Services Through Technology" 
              />
              
              <p className="text-[#4e5860] text-lg mb-8">
                Founded in 2015, SSN Consultancy has been at the forefront of digital transformation in Uttarakhand's public sector. We combine deep technical expertise with a profound understanding of government processes to deliver solutions that truly make a difference.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-[#fafbfc] p-6 rounded-lg border border-gray-100">
                  <h4 className="font-bold font-inter text-xl mb-4">Our Vision</h4>
                  <p className="text-[#4e5860]">To be the leading catalyst for digital transformation in Uttarakhand's public sector, creating sustainable and impactful technology solutions.</p>
                </div>
                
                <div className="bg-[#fafbfc] p-6 rounded-lg border border-gray-100">
                  <h4 className="font-bold font-inter text-xl mb-4">Our Mission</h4>
                  <p className="text-[#4e5860]">Delivering innovative, sustainable IT solutions that enhance government services and benefit communities while fostering digital inclusion.</p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-[#ff3c1f] opacity-10 rounded-lg"></div>
              <svg viewBox="0 0 500 400" className="rounded-lg shadow-xl relative z-10 w-full">
                <rect width="500" height="400" fill="#f8f9fa" />
                <circle cx="250" cy="150" r="100" fill="#ff3c1f" opacity="0.1" />
                <path d="M100 250 Q 250 50 400 250" stroke="#26313b" strokeWidth="8" fill="none" />
                <text x="250" y="200" textAnchor="middle" fill="#26313b" fontSize="24" fontWeight="bold">Vision</text>
                <path d="M100 300 Q 250 450 400 300" stroke="#ff3c1f" strokeWidth="8" fill="none" />
                <text x="250" y="300" textAnchor="middle" fill="#26313b" fontSize="24" fontWeight="bold">Mission</text>
              </svg>
            </div>
          </div>
        </div>
      </section>
      
      {/* CEO's Message */}
      <section className="py-20 bg-[#fafbfc]">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="CEO's Message" 
            title="Leading With Purpose" 
            centered={true}
          />
          
          <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-lg shadow-md border-l-4 border-[#ff3c1f]">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-8">
              <div className="w-32 h-32 rounded-full bg-[#26313b] bg-opacity-10 flex items-center justify-center flex-shrink-0">
                <svg viewBox="0 0 24 24" className="w-16 h-16 text-[#26313b]">
                  <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                </svg>
              </div>
              <div>
                <p className="text-[#4e5860] text-lg italic mb-6">
                  "At SSN Consultancy, we believe that technology has the transformative power to improve the lives of citizens through better government services. Our team is dedicated to bridging the digital divide and ensuring that every initiative we undertake contributes to the greater good of society. By combining technical excellence with a deep understanding of public sector needs, we are building a more connected, efficient Uttarakhand."
                </p>
                <div>
                  <h4 className="font-bold font-inter text-xl">Rohit Sharma</h4>
                  <p className="text-[#4e5860]">CEO & Founder, SSN Consultancy</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Our Team" 
            title="Meet The Experts"
            description="Our diverse team brings together decades of experience in public sector IT transformation"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((team, index) => (
              <div key={index} className="bg-[#fafbfc] rounded-lg overflow-hidden shadow-md">
                <div className="h-48 bg-[#26313b] bg-opacity-10 flex items-center justify-center">
                  <svg viewBox="0 0 24 24" className="w-20 h-20 text-[#26313b] opacity-30">
                    <path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                  </svg>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold font-inter mb-1">{
                    index === 0 ? "Rohit Sharma" : index === 1 ? "Priya Patel" : "Amit Joshi"
                  }</h3>
                  <p className="text-[#ff3c1f] font-medium mb-4">{
                    index === 0 ? "CEO & Founder" : index === 1 ? "CTO" : "Head of Operations"
                  }</p>
                  <p className="text-[#4e5860] mb-4">
                    {index === 0 
                      ? "With over 15 years in government IT consulting, Rohit leads our strategic vision." 
                      : index === 1 
                        ? "Priya brings cutting-edge technical expertise with a focus on cloud architecture." 
                        : "Amit ensures our projects are delivered on time and exceed expectations."
                    }
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-16 bg-[#26313b] text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-6">Ready to Transform Your IT Infrastructure?</h2>
          <p className="text-[#d9e0e2] mb-8 max-w-3xl mx-auto">
            Join the many government departments we've helped modernize their digital capabilities.
          </p>
          <Link href="/contact">
            <Button className="bg-[#ff3c1f] text-white py-3 px-8 rounded font-medium hover:bg-opacity-90 transition-all duration-200">
              Contact Us Today
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
