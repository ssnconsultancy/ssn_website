import { Link } from "wouter";
import SectionHeading from "@/components/common/SectionHeading";
import { Button } from "@/components/ui/button";
import { allServices } from "@/data/services";
import { 
  ServerIcon, 
  ClipboardListIcon, 
  UsersIcon, 
  CloudIcon, 
  DatabaseIcon,
  ShieldIcon,
  LandmarkIcon,
  CircleIcon 
} from "lucide-react";

const Services = () => {
  // Map of service icons
  const serviceIcons: Record<string, React.ReactNode> = {
    "IT Architecture & Infrastructure": <ServerIcon className="text-[#ff3c1f] text-2xl" />,
    "PMO Implementation": <ClipboardListIcon className="text-[#ff3c1f] text-2xl" />,
    "Training & Capacity Building": <UsersIcon className="text-[#ff3c1f] text-2xl" />,
    "AWS Cloud Services": <CloudIcon className="text-[#ff3c1f] text-2xl" />,
    "Database Management": <DatabaseIcon className="text-[#ff3c1f] text-2xl" />,
    "Cybersecurity & Compliance": <ShieldIcon className="text-[#ff3c1f] text-2xl" />,
    "Banking Consultancy": <LandmarkIcon className="text-[#ff3c1f] text-2xl" />
  };

  return (
    <div className="bg-[#fafbfc]">
      {/* Services Hero */}
      <section className="bg-[#26313b] text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0"></div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter mb-6">Our Services</h1>
            <p className="text-lg text-[#d9e0e2]">
              Comprehensive IT solutions tailored for public sector transformation
            </p>
          </div>
        </div>
      </section>

      {/* Services List */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Our Services" 
            title="Comprehensive IT Solutions" 
            description="End-to-end services to support your digital transformation journey"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {allServices.map((service) => (
              <div key={service.title} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="bg-[#26313b] bg-opacity-10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                  {serviceIcons[service.title] || <ServerIcon className="text-[#ff3c1f] text-2xl" />}
                </div>
                <h3 className="text-xl font-bold font-inter mb-3">{service.title}</h3>
                <p className="text-[#4e5860] mb-4">{service.description}</p>
                <ul className="space-y-2 text-[#4e5860]">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center">
                      <CircleIcon className="text-[#ff3c1f] mr-2" size={8} />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Our Process" 
            title="How We Deliver Excellence" 
            description="Our structured approach ensures successful implementations every time"
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {[
              {
                step: "1",
                title: "Discovery",
                description: "We thoroughly analyze your existing systems and requirements."
              },
              {
                step: "2",
                title: "Planning",
                description: "We develop a comprehensive roadmap for your transformation journey."
              },
              {
                step: "3",
                title: "Implementation",
                description: "Our experts deploy solutions with minimal disruption to operations."
              },
              {
                step: "4",
                title: "Support",
                description: "We provide ongoing maintenance and optimization of your systems."
              }
            ].map((process, index) => (
              <div key={index} className="relative">
                <div className="bg-[#26313b] w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold mb-6">
                  {process.step}
                </div>
                {index < 3 && (
                  <div className="absolute top-8 left-16 w-full h-1 bg-[#26313b] opacity-20 hidden lg:block"></div>
                )}
                <h3 className="text-xl font-bold font-inter mb-3">{process.title}</h3>
                <p className="text-[#4e5860]">{process.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#26313b] text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-6">Ready to Get Started?</h2>
          <p className="text-[#d9e0e2] mb-8 max-w-3xl mx-auto">
            Contact us today to discuss how our services can transform your organization.
          </p>
          <Link href="/contact">
            <Button className="bg-[#ff3c1f] text-white py-3 px-8 rounded font-medium hover:bg-opacity-90 transition-all duration-200">
              Request a Consultation
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;
