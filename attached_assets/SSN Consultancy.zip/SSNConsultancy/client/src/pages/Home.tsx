import { Link } from "wouter";
import Hero from "@/components/home/Hero";
import ServiceOverview from "@/components/home/ServiceOverview";
import SectionHeading from "@/components/common/SectionHeading";
import { Button } from "@/components/ui/button";
import { CheckIcon } from "lucide-react";

const Home = () => {
  return (
    <>
      <Hero />
      <ServiceOverview />
      
      {/* About Preview Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#ff3c1f] opacity-10 rounded-lg"></div>
                <svg viewBox="0 0 400 300" className="rounded-lg shadow-xl relative z-10 w-full">
                  <rect width="400" height="300" fill="#e6e6e6" />
                  <path d="M85.5 148.5s31.5-44 80-44 73 51 117 51 66-13 66-13" fill="none" stroke="#26313b" strokeWidth="6" />
                  <circle cx="140" cy="80" r="40" fill="#ff3c1f" opacity="0.3" />
                  <circle cx="280" cy="160" r="40" fill="#ff3c1f" opacity="0.3" />
                  <text x="200" y="150" dominantBaseline="middle" textAnchor="middle" fill="#26313b" fontSize="18" fontWeight="bold">SSN Consultancy</text>
                </svg>
              </div>
            </div>
            
            <div className="order-1 lg:order-2 space-y-6">
              <SectionHeading 
                tagline="About Us" 
                title="Transforming Public Sector Technology in Uttarakhand" 
              />
              
              <p className="text-[#4e5860] text-lg">
                Founded with a mission to revolutionize government IT infrastructure, SSN Consultancy brings expertise, innovation, and dedication to every project. Based in Dehradun, we understand the unique challenges and opportunities within Uttarakhand's public sector landscape.
              </p>
              
              <div className="pt-4 space-y-4">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-[#ff3c1f] flex items-center justify-center">
                      <CheckIcon className="text-white" size={12} />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold font-inter">Our Vision</h4>
                    <p className="text-[#4e5860]">To be the leading catalyst for digital transformation in Uttarakhand's public sector.</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-[#ff3c1f] flex items-center justify-center">
                      <CheckIcon className="text-white" size={12} />
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold font-inter">Our Mission</h4>
                    <p className="text-[#4e5860]">Delivering innovative, sustainable IT solutions that enhance government services and benefit communities.</p>
                  </div>
                </div>
              </div>
              
              <Link href="/about">
                <Button className="bg-[#26313b] text-white py-3 px-6 rounded font-medium hover:bg-opacity-90 transition-all duration-200 mt-4">
                  Learn More About Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
