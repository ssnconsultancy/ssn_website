import SectionHeading from "@/components/common/SectionHeading";
import ContactForm from "@/components/contact/ContactForm";
import { MapPinIcon, PhoneIcon, MailIcon, LinkedinIcon, TwitterIcon, FacebookIcon } from "lucide-react";

const Contact = () => {
  return (
    <div className="bg-[#fafbfc]">
      {/* Contact Hero */}
      <section className="bg-[#26313b] text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0"></div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter mb-6">Contact Us</h1>
            <p className="text-lg text-[#d9e0e2]">
              Get in touch with our team to discuss your IT transformation needs
            </p>
          </div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <SectionHeading 
                tagline="Contact Us" 
                title="Get in Touch" 
              />
              <p className="text-[#4e5860] text-lg mb-8">
                Have a question or want to discuss how we can support your organization? Reach out to our team, and we'll get back to you promptly.
              </p>
              
              <div className="space-y-6 mb-8">
                <div className="flex items-start">
                  <div className="bg-[#26313b] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center mr-4">
                    <MapPinIcon className="text-[#ff3c1f]" />
                  </div>
                  <div>
                    <h4 className="font-bold font-inter">Our Location</h4>
                    <p className="text-[#4e5860]">123 Tech Hub, Rajpur Road, Dehradun, Uttarakhand 248001</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#26313b] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center mr-4">
                    <PhoneIcon className="text-[#ff3c1f]" />
                  </div>
                  <div>
                    <h4 className="font-bold font-inter">Call Us</h4>
                    <p className="text-[#4e5860]">+91 135 2720000</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="bg-[#26313b] bg-opacity-10 w-12 h-12 rounded-lg flex items-center justify-center mr-4">
                    <MailIcon className="text-[#ff3c1f]" />
                  </div>
                  <div>
                    <h4 className="font-bold font-inter">Email Us</h4>
                    <p className="text-[#4e5860]">info@ssnconsultancy.com</p>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <a href="#" className="bg-[#26313b] bg-opacity-10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#26313b] hover:text-white transition-colors duration-200">
                  <LinkedinIcon size={18} />
                </a>
                <a href="#" className="bg-[#26313b] bg-opacity-10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#26313b] hover:text-white transition-colors duration-200">
                  <TwitterIcon size={18} />
                </a>
                <a href="#" className="bg-[#26313b] bg-opacity-10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-[#26313b] hover:text-white transition-colors duration-200">
                  <FacebookIcon size={18} />
                </a>
              </div>
            </div>
            
            <div>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Map */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Location" 
            title="Visit Our Office" 
            description="We're conveniently located in the heart of Dehradun"
            centered={true}
          />
          
          <div className="h-96 bg-gray-100 rounded-lg shadow-md overflow-hidden mt-12">
            {/* Map placeholder */}
            <div className="w-full h-full flex items-center justify-center bg-[#26313b] bg-opacity-5">
              <div className="text-center px-4">
                <MapPinIcon className="mx-auto mb-4 text-[#ff3c1f]" size={48} />
                <h3 className="text-xl font-bold mb-2">SSN Consultancy</h3>
                <p className="text-[#4e5860]">123 Tech Hub, Rajpur Road, Dehradun, Uttarakhand 248001</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
