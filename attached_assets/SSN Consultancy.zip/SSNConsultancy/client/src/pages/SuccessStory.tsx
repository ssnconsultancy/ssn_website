import { Link } from "wouter";
import SectionHeading from "@/components/common/SectionHeading";
import { Button } from "@/components/ui/button";
import { UserIcon } from "lucide-react";

const SuccessStory = () => {
  return (
    <div className="bg-[#fafbfc]">
      {/* Success Story Hero */}
      <section className="bg-[#26313b] text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0"></div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter mb-6">Success Story</h1>
            <p className="text-lg text-[#d9e0e2]">
              How SSN Consultancy transformed digital service delivery for Uttarakhand
            </p>
          </div>
        </div>
      </section>

      {/* Main Case Study */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading 
                tagline="Success Story" 
                title="The 12th Wonder Project"
              />
              <p className="text-[#d9e0e2] text-lg mb-8">
                A transformative initiative that revolutionized digital service delivery for a major government department in Uttarakhand, improving efficiency by 40% and citizen satisfaction by 65%.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="bg-[#4e5860] bg-opacity-20 p-6 rounded-lg">
                  <h4 className="font-bold font-inter text-lg mb-2 text-white">The Challenge</h4>
                  <p className="text-[#d9e0e2]">Legacy systems causing delays and inefficiencies in critical public services.</p>
                </div>
                
                <div className="bg-[#4e5860] bg-opacity-20 p-6 rounded-lg">
                  <h4 className="font-bold font-inter text-lg mb-2 text-white">Our Approach</h4>
                  <p className="text-[#d9e0e2]">End-to-end digital transformation with custom solutions and training.</p>
                </div>
                
                <div className="bg-[#4e5860] bg-opacity-20 p-6 rounded-lg">
                  <h4 className="font-bold font-inter text-lg mb-2 text-white">The Solution</h4>
                  <p className="text-[#d9e0e2]">Integrated platform connecting departments while improving security.</p>
                </div>
                
                <div className="bg-[#4e5860] bg-opacity-20 p-6 rounded-lg">
                  <h4 className="font-bold font-inter text-lg mb-2 text-white">The Results</h4>
                  <p className="text-[#d9e0e2]">40% efficiency increase and 65% improvement in citizen satisfaction.</p>
                </div>
              </div>
              
              <div className="bg-white bg-opacity-10 p-8 rounded-lg border-l-4 border-[#ff3c1f]">
                <p className="italic text-[#d9e0e2] mb-4">"SSN Consultancy delivered a transformative solution that has fundamentally changed how we serve our citizens. Their expertise and dedication made this complex project a resounding success."</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-[#ff3c1f] bg-opacity-20 flex items-center justify-center">
                    <UserIcon className="text-[#ff3c1f]" />
                  </div>
                  <div className="ml-4">
                    <h5 className="font-bold font-inter text-white">Director</h5>
                    <p className="text-sm text-[#d9e0e2]">Department of IT, Government of Uttarakhand</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-[#ff3c1f] opacity-10 rounded-lg"></div>
              <svg viewBox="0 0 400 300" className="rounded-lg shadow-xl relative z-10 w-full">
                <rect width="400" height="300" fill="#f8f9fa" />
                <path d="M50 150 L350 150" stroke="#ddd" strokeWidth="2" />
                <path d="M50 150 L350 150" stroke="#ff3c1f" strokeWidth="4" strokeDasharray="180 180" strokeDashoffset="180">
                  <animate attributeName="stroke-dashoffset" from="180" to="0" dur="2s" fill="freeze" />
                </path>
                <text x="50" y="130" fill="#26313b" fontWeight="bold">Before</text>
                <text x="350" y="130" textAnchor="end" fill="#26313b" fontWeight="bold">After</text>
                <circle cx="50" cy="150" r="10" fill="#26313b" />
                <circle cx="350" cy="150" r="10" fill="#ff3c1f" />
                <text x="200" y="190" textAnchor="middle" fill="#26313b" fontSize="18" fontWeight="bold">Project Performance</text>
                <text x="200" y="220" textAnchor="middle" fill="#4e5860">40% Efficiency Increase</text>
                <text x="200" y="250" textAnchor="middle" fill="#4e5860">65% Citizen Satisfaction Improvement</text>
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Project Details */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Project Details" 
            title="How We Made It Happen" 
            description="A deeper look at the transformation process"
            centered={true}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-12">
            <div className="bg-[#fafbfc] p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-bold font-inter mb-4 text-[#26313b]">Phase 1: Assessment</h3>
              <p className="text-[#4e5860] mb-4">
                We conducted a comprehensive audit of existing systems, identified pain points, and established key performance indicators.
              </p>
              <ul className="space-y-2 text-[#4e5860]">
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>System architecture review</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Stakeholder interviews</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Performance bottleneck identification</span>
                </li>
              </ul>
            </div>

            <div className="bg-[#fafbfc] p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-bold font-inter mb-4 text-[#26313b]">Phase 2: Implementation</h3>
              <p className="text-[#4e5860] mb-4">
                We developed and deployed a custom integrated platform with minimal disruption to ongoing operations.
              </p>
              <ul className="space-y-2 text-[#4e5860]">
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Microservices architecture deployment</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Legacy system integration</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Secure API development</span>
                </li>
              </ul>
            </div>

            <div className="bg-[#fafbfc] p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-bold font-inter mb-4 text-[#26313b]">Phase 3: Training & Support</h3>
              <p className="text-[#4e5860] mb-4">
                We ensured smooth adoption through comprehensive training and established ongoing support systems.
              </p>
              <ul className="space-y-2 text-[#4e5860]">
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Hands-on training sessions</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>Documentation & knowledge transfer</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-[#ff3c1f] w-2 h-2 rounded-full mt-2 mr-2"></span>
                  <span>24/7 support establishment</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="py-20 bg-[#fafbfc]">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Results" 
            title="Measurable Impact" 
            description="The 12th Wonder Project delivered significant, quantifiable improvements"
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {[
              { metric: "40%", description: "Improvement in operational efficiency" },
              { metric: "65%", description: "Increase in citizen satisfaction ratings" },
              { metric: "30%", description: "Reduction in service delivery time" },
              { metric: "₹2.5Cr", description: "Annual cost savings" }
            ].map((result, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-md text-center">
                <div className="text-4xl font-bold text-[#ff3c1f] mb-4">{result.metric}</div>
                <p className="text-[#4e5860]">{result.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#26313b] text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-6">Ready for Your Success Story?</h2>
          <p className="text-[#d9e0e2] mb-8 max-w-3xl mx-auto">
            Let's discuss how we can create similar transformative results for your organization.
          </p>
          <Link href="/contact">
            <Button className="bg-[#ff3c1f] text-white py-3 px-8 rounded font-medium hover:bg-opacity-90 transition-all duration-200">
              Start Your Transformation
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default SuccessStory;
