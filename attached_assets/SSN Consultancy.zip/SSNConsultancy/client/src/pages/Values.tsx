import { Link } from "wouter";
import SectionHeading from "@/components/common/SectionHeading";
import { Button } from "@/components/ui/button";
import { companyValues } from "@/data/values";
import {
  HeartHandshakeIcon,
  LightbulbIcon,
  UsersIcon,
  CheckCircleIcon,
  GlobeIcon,
  SproutIcon,
  LockIcon
} from "lucide-react";

const Values = () => {
  // Map of value icons
  const valueIcons: Record<string, React.ReactNode> = {
    "Integrity": <HeartHandshakeIcon className="text-[#ff3c1f] text-2xl" />,
    "Innovation": <LightbulbIcon className="text-[#ff3c1f] text-2xl" />,
    "Collaboration": <UsersIcon className="text-[#ff3c1f] text-2xl" />,
    "Excellence": <CheckCircleIcon className="text-[#ff3c1f] text-2xl" />,
    "Social Impact": <GlobeIcon className="text-[#ff3c1f] text-2xl" />,
    "Sustainability": <SproutIcon className="text-[#ff3c1f] text-2xl" />,
    "Trust": <LockIcon className="text-[#ff3c1f] text-2xl" />
  };

  return (
    <div className="bg-[#fafbfc]">
      {/* Values Hero */}
      <section className="bg-[#26313b] text-white py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[#4e5860] opacity-10 z-0"></div>
        <div className="container mx-auto px-4 md:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-inter mb-6">Our Values</h1>
            <p className="text-lg text-[#d9e0e2]">
              The principles that guide every decision and solution we deliver
            </p>
          </div>
        </div>
      </section>

      {/* Values Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Our Values" 
            title="The Principles That Guide Us" 
            description="Our seven core values shape every decision and solution we deliver"
            centered={true}
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {companyValues.map((value) => (
              <div key={value.title} className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 text-center">
                <div className="bg-[#26313b] bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
                  {valueIcons[value.title] || <HeartHandshakeIcon className="text-[#ff3c1f] text-2xl" />}
                </div>
                <h3 className="text-xl font-bold font-inter mb-3">{value.title}</h3>
                <p className="text-[#4e5860]">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values in Action */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8">
          <SectionHeading 
            tagline="Values in Action" 
            title="How We Live Our Values" 
            description="Our values aren't just words on a page - they guide our daily actions"
            centered={true}
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mt-12">
            <div className="space-y-8">
              {[
                {
                  title: "Contributing to Digital Uttarakhand",
                  description: "Our team regularly volunteers technical expertise for digital literacy initiatives across rural Uttarakhand."
                },
                {
                  title: "Sustainable Technology Practices",
                  description: "We design our solutions with energy efficiency in mind and prioritize vendors with strong environmental commitments."
                },
                {
                  title: "Public Sector Innovation Workshops",
                  description: "We host quarterly workshops for government employees to foster a culture of innovation in public service."
                }
              ].map((item, index) => (
                <div key={index} className="flex">
                  <div className="flex-shrink-0 mt-1">
                    <div className="w-5 h-5 rounded-full bg-[#ff3c1f] flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                    </div>
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold font-inter">{item.title}</h4>
                    <p className="text-[#4e5860]">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 bg-[#ff3c1f] opacity-10 rounded-lg"></div>
              <svg viewBox="0 0 500 300" className="rounded-lg shadow-xl relative z-10 w-full">
                <rect width="500" height="300" fill="#f8f9fa" />
                <g transform="translate(250, 150)">
                  <circle r="100" fill="#26313b" fillOpacity="0.05" />
                  <circle r="80" fill="#26313b" fillOpacity="0.1" />
                  <circle r="60" fill="#ff3c1f" fillOpacity="0.2" />
                  <text textAnchor="middle" fill="#26313b" fontSize="18" fontWeight="bold" y="-10">Our Values</text>
                  <text textAnchor="middle" fill="#26313b" fontSize="14" y="20">At The Core</text>
                  <text textAnchor="middle" fill="#26313b" fontSize="14" y="40">Of Everything We Do</text>
                </g>
                {['Integrity', 'Innovation', 'Excellence', 'Trust'].map((value, i) => (
                  <text 
                    key={i} 
                    x={(i % 2 === 0 ? 80 : 420)} 
                    y={70 + i * 60} 
                    fill="#4e5860" 
                    textAnchor={i % 2 === 0 ? "start" : "end"}
                  >
                    {value}
                  </text>
                ))}
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-[#26313b] text-white">
        <div className="container mx-auto px-4 md:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-inter mb-6">Partner With a Value-Driven Team</h2>
          <p className="text-[#d9e0e2] mb-8 max-w-3xl mx-auto">
            Experience the difference of working with a consultancy that puts principles first.
          </p>
          <Link href="/contact">
            <Button className="bg-[#ff3c1f] text-white py-3 px-8 rounded font-medium hover:bg-opacity-90 transition-all duration-200">
              Start the Conversation
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Values;
